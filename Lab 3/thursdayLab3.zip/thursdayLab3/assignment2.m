knd = load('lab3_2.mat');
knd = knd.lab3_2